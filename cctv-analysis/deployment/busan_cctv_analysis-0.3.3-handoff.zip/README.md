# 화장실 분석 0.3.3 — 기본 n + 선택형 북쪽 GPU s

기본 `python -m cctv`와 AnalysisService 공개 인터페이스는 0.3.2 그대로다. 북쪽 s는 아래 별도 모듈을 명시적으로 선택할 때만 실행한다. 남·동은 n을 유지한다. 내부/외부 구역·마스킹·확인시간·출입·대기·13열 CSV·계산식은 바꾸지 않았다. 최근 구역 실험은 포함하지 않는다.

## 설치: Python 3.13의 새 가상환경

ZIP을 새 폴더에 풀고 그 폴더에서 실행한다. 기존 0.3.2 가상환경은 덮어쓰지 않는다. 기본 CPU n:

```powershell
py -3.13 -m venv .venv-cpu
$py = '.\.venv-cpu\Scripts\python.exe'
& $py -c "import sys; print(sys.executable, sys.version)"
& $py -m pip install torch==2.14.1 torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cpu
& $py -m pip install '.\dist\busan_cctv_analysis-0.3.3-py3-none-any.whl[analysis]'
& $py -m pip check
& $py -c "import ultralytics, importlib.metadata as m; print(ultralytics.__version__, m.version('ultralytics'))"
```

북쪽 GPU s는 별도 환경이다. 검증 환경은 Windows·Python 3.13.9·RTX4060·FP32·torch2.14.1+cu132다. 호환 NVIDIA 드라이버가 필요하며 다른 GPU/드라이버 조합을 보장하지 않는다.

```powershell
py -3.13 -m venv .venv-gpu
$py = '.\.venv-gpu\Scripts\python.exe'
& $py -m pip install torch==2.14.1 torchvision==0.29.1 --index-url https://download.pytorch.org/whl/cu132
& $py -m pip install '.\dist\busan_cctv_analysis-0.3.3-py3-none-any.whl[analysis,gpu-tools]'
& $py -m pip check
& $py -c "import sys,torch,ultralytics,importlib.metadata as m; print(sys.executable,sys.version); print(torch.__version__,torch.cuda.is_available()); print(ultralytics.__version__,m.version('ultralytics'))"
```

[PyTorch 공식 CUDA 빌드](https://download.pytorch.org/whl/cu132/torch/)에서 해당 버전을 확인할 수 있다. CPU 잠금 파일의 `+cpu` 제약을 GPU 환경에 적용하지 않는다. 앱·자식 분석 프로세스·pip 모두 선택한 `$py`를 사용한다. Python3.14는 패키지 지원 범위 밖이다.

## 공식 가중치 준비

```powershell
New-Item -ItemType Directory weights
Invoke-WebRequest https://github.com/ultralytics/assets/releases/download/v8.3.0/yolo11n.pt -OutFile weights/yolo11n.pt
Invoke-WebRequest https://github.com/ultralytics/assets/releases/download/v8.3.0/yolo11s.pt -OutFile weights/yolo11s.pt
Get-FileHash weights/yolo11s.pt -Algorithm SHA256
```

기존 파일이 있다면 덮어쓰지 말고 해시를 확인한다. n SHA-256: `0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1`.
s SHA-256: `85a76fe86dd8afe384648546b56a7a78580c7cb7b404fc595f97969322d502d5`.
프로필은 s 해시가 다르거나 파일/CUDA가 없으면 오류로 종료한다. CPU/MPS/auto로 자동 전환하지 않는다. [Ultralytics 공식 모델 안내](https://docs.ultralytics.com/models/yolo11/)와 [라이선스](https://www.ultralytics.com/license)를 확인한다. 가중치·원본 영상은 ZIP에 첨부하지 않는다.

## 기본 n 실행 — 세 환경 공통

실제 영상 경로를 지정한다. 예시는 북쪽이며 남·동은 각각 configs/south.json, configs/east.json과 해당 영상을 선택한다.

```powershell
& $py -m cctv analyze --config configs/north.json --profile demo --device cpu --model weights/yolo11n.pt --video '영상경로/북쪽_화장실_cctv.mp4' --output-dir results/north-n --no-video --end 3.25
```

demo는 초기 내부 29명·촬영시각 등의 가상 가정을 사용하는 재현 프로필이다. 실제 운영 메타데이터는 operating 프로필에서 별도로 설정한다. 기존 세 영상은 번들 마스킹을 사용한다. 다른 카메라 구도는 마스킹 재설정이 필요하다. 예시 CSV는 비교 자료이고 추론 입력이 아니다.

## 명시적 북쪽 north-gpu-s 실행

GPU 환경의 Python으로 실행한다. 짧은 확인 후 `--end`를 빼면 전체 길이를 처리한다. `--save-video`는 전체 결과 영상이 필요할 때만 추가한다.

```powershell
$py = '.\.venv-gpu\Scripts\python.exe'
& $py -m cctv.gpu_profile --runtime-profile north-gpu-s --profile demo --model weights/yolo11s.pt --video '영상경로/북쪽_화장실_cctv.mp4' --output-dir results/north-s --end 3.25
& $py -m cctv.gpu_profile --runtime-profile north-gpu-s --profile demo --model weights/yolo11s.pt --video '영상경로/북쪽_화장실_cctv.mp4' --output-dir results/north-s-full --save-video
```

설정은 번들 북쪽 기본 구역으로 고정된다. CPU·macOS/MPS에서 s가 자동 선택되지 않는다. 남·동에 이 프로필을 적용할 수 없다. 기존 API는 바꾸지 않았으며 선택 헬퍼도 같은 AnalysisService를 사용한다:

```python
from cctv import AnalysisService
from cctv.gpu_profile import start_north_gpu_s

if __name__ == '__main__':
    with AnalysisService() as service:
        job = start_north_gpu_s(service, owner='team-demo',
            video_path='북쪽_화장실_cctv.mp4', model_path='weights/yolo11s.pt',
            output_dir='results/north-s', profile='demo', end=3.25)
        for record in job.records():
            print(record['csv_row'], record['detail']['state'])
        print(job.status())
```

## 검증 결과와 제한

현재 개발 영상의 북쪽 통과 추정 F1 **82.35→88.89%, +6.54%p**. 입장·퇴장 각 1건을 추가 복구하고 기존 정상 14건을 유지했다. 자동 확정 기준 F1은 64.71→72.22%다. 허용시간은 같은 방향·±1초·일대일로 유지했다.

북쪽 s 전체 입장 6·퇴장 10, 초기 29에 따른 최종 내부 추정 25명. 전체 결과 영상/CSV는 검증된 GPU 관측을 재사용해 동일 판정·API 경로로 재생성한 자료이며 새 추론·새 성능 측정이 아니다. 저장된 자동 결과를 수동 정답으로 보정하지 않았다.

단일 RTX4060 paced 시험: 2,524프레임, CSV105행, 지연 p50 **27.83ms**, p95 **37.01ms**, 최대 **42.16ms**, 미처리·중단0. worker 분석 진입→준비 완료12.64초, 예정 입력 시작까지12.74초. 프로세스 생성/import 및 인터프리터 시작은 준비 시간에서 제외했다. 로컬 CSV flush 측정이며 실제 카메라·네트워크 시험은 아니다.

CPU s는 북쪽 전체 루프79.93→149.50초로 느려졌다. s의 CPU 운용은 권하지 않으며 macOS·다중 입력·별도 영상 일반화는 미검증이다. 한 GPU 단일 입력 결과로 다중 영상이나 모든 환경의 실시간 제공을 보장하지 않는다.

기존 paced 검증기의 후보 포함 합산식은 0.3.2의 confirmed-only 정책과 달랐다. 이 패치는 실험 검증 사본에서 해당 식만 confirmed+grace로 바로잡고 CSV·상태·순서·프레임 검사를 유지한다. 후보를 잘못 포함하거나 확정 합계/CSV를 틀리게 만든 입력은 회귀 테스트에서 실패해야 한다. 분석의 대기 정책은 변경하지 않았다.

0.3.2 배포물은 그대로 보존했다. 이번 0.3.3은 로컬 인계 준비본이며 GitHub 게시·commit·push는 하지 않았다. 원본/결과 영상의 공개 공유 권한은 별도 확인이 필요하다. 기존 API·설정 상세는 docs/README_032.md를 참고한다.
