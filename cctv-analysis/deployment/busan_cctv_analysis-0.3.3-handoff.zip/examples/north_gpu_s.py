from cctv import AnalysisService
from cctv.gpu_profile import start_north_gpu_s
import argparse

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--video',required=True);p.add_argument('--model',required=True);p.add_argument('--output',required=True)
    a=p.parse_args()
    with AnalysisService() as service:
        job=start_north_gpu_s(service,owner='team',video_path=a.video,model_path=a.model,output_dir=a.output,profile='demo')
        for record in job.records():print(record['csv_row'],record['detail']['state'])
        print(job.status())
