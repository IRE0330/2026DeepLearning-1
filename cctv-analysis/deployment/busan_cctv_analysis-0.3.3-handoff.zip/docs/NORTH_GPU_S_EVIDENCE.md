# 북쪽 YOLO11s 단일 GPU 적합성 검증 — 2026-10-21

**판단: 이 RTX 4060에서 북쪽 단일 저장 영상의 원본 FPS 입력·1초 CSV 기록 시험을 통과했다.** 실제 카메라/네트워크, 동시 다중 입력, 다른 GPU·별도 영상 일반화는 검증하지 않았다. 기본 설정·배포본은 바꾸지 않는다.

기존 `.venv-gpu`의 RTX 4060 / Torch 2.14.1+cu132 / torchvision 0.29.1+cu132 / Python 3.13.9 / ultralytics 8.4.177 / OpenCV 5.0.0.93 / numpy 2.5.4 / lap 0.5.13 / av 19.0.1을 유지했다. 0.3.2 기본 구역·규칙, imgsz 640, confidence 0.1, iou 0.7, ByteTrack 및 대기 조건은 직전 북쪽 전체 설정 그대로다. 두 모델 모두 실제 CUDA FP32(fp16=false), 영상 출력 없음, 0번부터 EOF 2,524프레임을 순차 실행했다.

기존 보관 n 전체 결과는 실제 FP32 backend 기록이 없고 현재 루프와 측정 경로도 달라 재사용하지 않았다. n/s 각각 새 GPU 실행으로 동일 조건의 기준을 확보했다. 라이브러리 업그레이드는 하지 않았다.

- n SHA-256: `0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1`
- s SHA-256: `85a76fe86dd8afe384648546b56a7a78580c7cb7b404fc595f97969322d502d5`

## 고정 정답 평가

`baseline_evaluation_20261021_02/north/truth_snapshot/events.csv`의 20건과 동일 방향·±1초·일대일 기존 평가기를 사용했다. 두 시각 기준을 섞지 않았다.

|시각 기준|모델|TP|FP|FN|P (%)|R (%)|F1 (%)|
|---|---|---:|---:|---:|---:|---:|---:|
|통과 추정|n|14|0|6|100.00|70.00|82.35|
|통과 추정|s|16|0|4|100.00|80.00|88.89|
|자동 확정|n|11|3|9|78.57|55.00|64.71|
|자동 확정|s|13|3|7|81.25|65.00|72.22|

s−n 변화: 통과 추정 ΔP 0 / ΔR +10.00 / ΔF1 +6.54%p, 자동 확정 ΔP +2.68 / ΔR +10.00 / ΔF1 +7.52%p. CPU 전체 비교와 두 모델의 TP/FP/FN/P/R/F1은 같다.

CPU에서 확인한 실제 퇴장(정답 5.5초)과 입장(11.833333초)이 GPU s에도 유지됐다. 기존 n 정상 14건은 GPU s에서 모두 유지되며 방향 변경·추가 취소가 없다. CPU의 원본 검수 자료를 재사용하고, CPU/GPU 이벤트별 동일 프레임 박스 궤적 평균 IoU>0.8 및 최소 5개 공통 프레임으로 인물 대응을 검증했다. ID 숫자 일치만으로 대응하지 않았다.

장치 변경 후 **좌표·검출 출력·추적 상태가 비트 단위로 동일하지는 않다.** 원시 검출 출력 박스 합계 n은 CPU 12,483→GPU 12,481, s는 11,003→11,004이다. n 관측 공백 초기화는 42→46, s는 31→31이다. 작은 통과 추정 시각 차이와 ID 차이는 `cpu_gpu_correspondence.json`에 기록했다. 이벤트·평가 유지가 모든 대기 상태/CSV의 CPU 일치까지 뜻하지는 않는다.

## GPU 비 paced 루프

|모델|입장/퇴장|시간|FPS|
|---|---|---:|---:|
|n|5/9|41.94초|60.18|
|s|6/10|39.32초|64.19|

워밍업 뒤 디코딩·탐지·추적·판정·메모리 관측 캡처를 포함하고 영상 저장·CSV 전달 비용은 제외했다. n/s 각 1회 순차 실행이라 GPU 클록·열·OS 부하·캐시를 통제한 속도 우열 벤치마크는 아니다. 이 값만으로 실시간 적합성을 선언하지 않고 아래 paced 실측을 사용했다.

## s 단일 전체 paced CSV 시험

기존 `cctv.paced.run_simulation`과 `scripts/verify_paced_input.py`를 재사용했다. 원본 24 FPS, queue=8, GPU inference slot=1, soft lag=5초·지속 10초, hard lag=15초를 유지했다. 입력 예정 시각은 고정 monotonic 원점이며 프레임을 건너뛰거나 원점을 뒤로 밀지 않는다.

- worker 분석 진입→local input ready: **12.642초**. worker 진입→고정 입력 시작: **12.742초**.
- 준비 시간은 영상 확인·해시, 모델 로딩·워밍업 및 0.1초 예정 시작 대기를 포함한다. 프로세스 생성/import·Python 인터프리터 시작 시간은 포함하지 않는다. driver 시작 시각은 기존 검증기 실패 전에 저장되지 않아 별도로 추정하지 않았다.
- 분석 입력 시작 후 각 1초 경계 예정 시각→CSV flush 지연: **p50 27.83ms / p95 37.01ms / 최대 42.16ms** (105건).
- 전체 2,524프레임 처리, 정규 CSV 105행. 미처리 **0**, 누락/중복 **0**, 조기 처리 **0**. 상태 `completed`, 중단 사유 `None`.
- 13열 CSV·구간 집계·시간 순서·프레임 순서 검증을 통과했다. paced s의 16개 이벤트는 GPU 비 paced s와 ID·방향·프레임·통과/확정 시각까지 동일했다.
- 기존 검증기는 대기 후보를 외부 대기 합계에 포함하는 검사에서 실패했다. 동결 0.3.2 core/usage는 후보를 제외하고 확정 관측+유예만 집계한다. 기존 검증기와 분석 결과를 보존하고 `verify_paced_032_policy.py` 실험 사본에서 그 검증식 한 줄만 실제 정책에 맞춰 재검증했다. 분석 재실행·대기 로직/CSV/설정 변경 없이 나머지 검사를 그대로 유지해 전체 105행을 통과했다.
- 마지막 0.166667초는 정규 1초 CSV 행으로 부풀리지 않으며 remainder에 보존된다. 지연은 로컬 파일 flush 기준이며 fsync의 물리 저장 내구성이나 외부 앱/네트워크 수신 완료를 측정한 값은 아니다.

## 실행·자료

```powershell
foreach ($variant in @("n", "s")) {
  & .\.venv-gpu\Scripts\python.exe -X utf8 -B reviews\north_gpu_yolo11s_20261021_01\run_compare.py --room north --variant $variant
}
.\.venv-gpu\Scripts\python.exe -X utf8 -B reviews\north_gpu_yolo11s_20261021_01\evaluate_full.py
.\.venv-gpu\Scripts\python.exe -X utf8 -B reviews\north_gpu_yolo11s_20261021_01\run_paced.py
```

완료된 paced 자료의 0.3.2 정책 검증은 `verify_completed_paced.py`로 별도 수행했다. 원래 검증기의 실패 로그도 남겨 두었다.
이미 완료한 결과는 덮어쓰지 않으며 재실행은 새 폴더를 지정해야 한다.
- paced 원시 자료: `reviews\north_gpu_yolo11s_20261021_01\paced\paced_single_20261021_212602_388f495b\north\north_20261021_212603_7b9b6566`의 `csv_latency.csv`, `frame_arrivals.csv`, `timing_summary.json`, `usage_summary.csv`.
- `paced_result.json`: 기존 검증기의 전체 결과, 준비 시간, 미처리·중단 및 이벤트 비교.
- `evaluation/{n,s}/north/{crossing_estimate,confirmation}/event_audit.json`: 매칭·미매칭 정답·예측.
- 기존 보호 입력 254개·미커밋 파일 7개·직전 전체 비교 산출물의 해시가 유지됐다. 남·동 실행, 기본/번들 설정 변경, 배포 갱신, 삭제, commit·push는 하지 않았다.

**북쪽 YOLO11s는 이 GPU·단일 저장 영상 조건에서 실시간 입력 처리 후보로 유효하다. 운영 카메라·네트워크 연동과 별도 영상 일반화는 추가 검증 대상이다.**
